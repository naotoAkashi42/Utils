﻿using OmProjectAnalyzer.Models;
using System.Text;
using Utils;

namespace OmProjectAnalyzer.Analyzer
{
    internal class ProgramAnalyzer
    {
        public static IReadOnlyList<string> GetSymbolsInLadderProgram(IReadOnlyList<Program> programs)
        {
            var symbols = new List<string>();
            foreach (var program in programs)
            {
                symbols.AddRange(program.GetAllSymbols());
            }
            return symbols.Where(s =>! string.IsNullOrEmpty(s)).ToList();
        }

        public static void OutputProgarmLadderInfoToCsv(IReadOnlyList<Program> programs, IReadOnlyList<FBDefine> fBDefines, FileInfo target)
        {
            using (var sr = new StreamWriter(Path.Combine(FileIo.DesktopFullPath, $"result_{target.Name}.csv"), false, Encoding.UTF8))
            {
                var fbTypeCntInProgramList = new List<IReadOnlyDictionary<string, int>>();
                var variablesList = new List<string>();
                foreach (var program in programs)
                {
                    sr.WriteLine(program.Name);
                    foreach (var section in program.Sections)
                    {
                        sr.WriteLine(section.Name);
                        sr.WriteLine($"RungNo,LD,OUT,FBFUN,BOXST");
                        foreach (var rung in section.Rungs)
                        {
                            sr.WriteLine($"rung-{rung.Idx},{rung.Contacts.Count},{rung.Coils.Count},{rung.Fbs.Count},{rung.BoxSTs.Count}");
                            foreach (var mnemonic in rung.GetRowMnemonics())
                            {
                                sr.Write($"{mnemonic}");
                            }
                            // 後で使うのここで作っとく。
                            fbTypeCntInProgramList.Add(rung.GetFbAndCnt());

                            variablesList.AddRange(rung.GetVariablesAndParameters());
                        }
                        sr.WriteLine();
                    }
                    sr.WriteLine();
                }

                var fbTypeCntInFbBodyList = new List<IReadOnlyDictionary<string, int>>();
                sr.WriteLine("FB Define");
                foreach (var fBDefine in fBDefines)
                {
                    sr.WriteLine(fBDefine.Name);
                    sr.WriteLine($"No,LD,OUT,FBFUN,BOXST");
                    foreach (var rung in fBDefine.Body.Rungs)
                    {
                        sr.WriteLine($"{rung.Idx},{rung.Contacts.Count},{rung.Coils.Count},{rung.Fbs.Count},{rung.BoxSTs.Count}");
                        foreach (var mnemonic in rung.GetRowMnemonics())
                        {
                            sr.WriteLine($"{mnemonic}");
                        }
                        // 後で使うのここで作っとく。
                        fbTypeCntInFbBodyList.Add(rung.GetFbAndCnt());

                        variablesList.AddRange(rung.GetVariablesAndParameters());
                    }
                    sr.WriteLine();
                }
                sr.WriteLine();

                // BOX STの中身は含んでない。
                sr.WriteLine("ラダー内で使っているシンボルで一番長いシンボル");
                var symbolsInLadder = GetSymbolsInLadderProgram(programs);

                //TODO: STしかないプロジェクトで落ちるので暫定対応
                if (!(symbolsInLadder.Count == 0))
                {
                    var longestLength = symbolsInLadder.Max(s => s.Length);
                    var longestSym = symbolsInLadder.FirstOrDefault(s => s.Length == longestLength);
                    sr.WriteLine($"{longestSym},{longestSym.Length}");
                }
                sr.WriteLine();

                sr.WriteLine("プログラム/FBFUNのラダー内で使っている一番長い変数名");
                var longestVariableName = GetLongestVariableNameInLadderProgram(programs, fBDefines);
                sr.WriteLine($"{longestVariableName},{longestVariableName.Length}");

                sr.WriteLine();

                sr.WriteLine("ラダー内で使っている一番長いFBFUN名");
                var longestFbName = GetLongestFbFunNameInLadderProgram(programs);
                sr.WriteLine($"{longestFbName},{longestFbName.Length}");

                sr.WriteLine();

                //TODO: STしかないプロジェクトで落ちるので暫定対応
                if (!(symbolsInLadder.Count == 0))
                {
                    sr.WriteLine("ラダーで使っているシンボル(変数/FBFUN名/引数名)の平均値");
                    sr.WriteLine(symbolsInLadder.Select(s => s.Length).Average());
                }

                sr.WriteLine();
                sr.WriteLine("ラダーで使っているFBFUNの種類と一覧");
                var dic = new Dictionary<string, int>();
                foreach (var fBdic in fbTypeCntInProgramList.Where(f => f.Count != 0))
                {
                    foreach (var e in fBdic)
                    {
                        if (dic.Keys.Contains(e.Key))
                        {
                            dic[e.Key] += e.Value;
                            continue;
                        }
                        dic.Add(e.Key, e.Value);
                    }
                }
                foreach (var ele in dic)
                {
                    sr.WriteLine($"{ele.Key},{ele.Value}");
                }

                sr.WriteLine("ラダー内で使っている変数の一覧,文字列長");
                foreach (var v in variablesList)
                {
                    sr.WriteLine($"{v},{v.Length}");
                }
            }
        }

        public static void OutputVariableAndParams(IReadOnlyList<Program> programs, IReadOnlyList<FBDefine> fBDefines, FileInfo target)
        {
            // 変数名・FB実引数・FB実引数名　全部
            using (var sr = new StreamWriter(Path.Combine(Utils.FileIo.DesktopFullPath, $"result_variables_params_{DateTime.Now.ToString("yyyyMMddHH")}.csv"), true, Encoding.UTF8))
            {
                var variablesList = new List<string>();
                foreach (var program in programs)
                {
                    foreach (var section in program.Sections)
                    {
                        foreach (var rung in section.Rungs)
                        {
                            variablesList.AddRange(rung.GetVariablesAndParameters());
                        }
                    }
                }

                foreach (var fBDefine in fBDefines)
                {
                    foreach (var rung in fBDefine.Body.Rungs)
                    {
                        variablesList.AddRange(rung.GetVariablesAndParameters());
                    }
                }

                // BOX STの中身は含んでない。
                foreach (var v in variablesList)
                {
                    sr.WriteLine($"{v},{v.Length}");
                }
            }

            // 接点/コイル　変数
            using (var sr = new StreamWriter(Path.Combine(Utils.FileIo.DesktopFullPath, $"result_coil_contact_{DateTime.Now.ToString("yyyyMMddHH")}.csv"), true, Encoding.UTF8))
            {
                var coil_contact_variable = new List<string>();
                foreach (var program in programs)
                {
                    foreach (var section in program.Sections)
                    {
                        foreach (var rung in section.Rungs)
                        {
                            coil_contact_variable.AddRange(rung.Contacts.Select(c => c.Variable));
                            coil_contact_variable.AddRange(rung.Coils.Select(c => c.Variable));
                        }
                    }
                }

                foreach (var fBDefine in fBDefines)
                {
                    foreach (var rung in fBDefine.Body.Rungs)
                    {
                        coil_contact_variable.AddRange(rung.Contacts.Select(c => c.Variable));
                        coil_contact_variable.AddRange(rung.Coils.Select(c => c.Variable));
                    }
                }

                // BOX STの中身は含んでない。
                foreach (var v in coil_contact_variable)
                {
                    sr.WriteLine($"{v},{v.Length}");
                }
            }

            // FB引数名
            using (var sr = new StreamWriter(Path.Combine(Utils.FileIo.DesktopFullPath, $"result_fbParam_{DateTime.Now.ToString("yyyyMMddHH")}.csv"), true, Encoding.UTF8))
            {
                var fbArgs = new List<string>();
                foreach (var program in programs)
                {
                    foreach (var section in program.Sections)
                    {
                        foreach (var rung in section.Rungs)
                        {
                            foreach (var args in rung.Fbs.Select(f => f.Args))
                            {
                                fbArgs.AddRange(args.Select(a => a.Name));
                            }
                        }
                    }
                }

                foreach (var fBDefine in fBDefines)
                {
                    foreach (var rung in fBDefine.Body.Rungs)
                    {
                        foreach (var args in rung.Fbs.Select(f => f.Args))
                        {
                            fbArgs.AddRange(args.Select(a => a.Name));
                        }
                    }
                }

                // BOX STの中身は含んでない。
                foreach (var v in fbArgs.Where(a => !string.IsNullOrEmpty(a)))
                {
                    sr.WriteLine($"{v},{v.Length}");
                }
            }

            // FB実引数
            using (var sr = new StreamWriter(Path.Combine(Utils.FileIo.DesktopFullPath, $"result_fbArg_{DateTime.Now.ToString("yyyyMMddHH")}.csv"), true, Encoding.UTF8))
            {
                var fbArgs = new List<string>();
                foreach (var program in programs)
                {
                    foreach (var section in program.Sections)
                    {
                        foreach (var rung in section.Rungs)
                        {
                            foreach (var args in rung.Fbs.Select(f => f.Args))
                            {
                                fbArgs.AddRange(args.Select(a => a.ActualArg));
                            }
                        }
                    }
                }

                foreach (var fBDefine in fBDefines)
                {
                    foreach (var rung in fBDefine.Body.Rungs)
                    {
                        foreach (var args in rung.Fbs.Select(f => f.Args))
                        {
                            fbArgs.AddRange(args.Select(a => a.ActualArg));
                        }
                    }
                }

                // BOX STの中身は含んでない。
                foreach (var v in fbArgs.Where(a => !string.IsNullOrEmpty(a)))
                {
                    sr.WriteLine($"{v},{v.Length}");
                }
            }
        }


        private static string GetLongestVariableNameInLadderProgram(IReadOnlyList<Program> programs, IReadOnlyList<FBDefine> fBDefines)
        {
            var symbols = new List<string>();
            foreach (var program in programs)
            {
                foreach (var section in program.Sections)
                {
                    foreach (var rung in section.Rungs)
                    {
                        // LD命令で使ってる変数
                        symbols.AddRange(rung.Contacts.Select(c => c.Variable));

                        // Out命令で使ってる変数
                        symbols.AddRange(rung.Coils.Select(c => c.Variable));

                        // FB インスタンス変数
                        symbols.AddRange(rung.Fbs.Select(f => f.InstanceName));

                        // FB/FUN　引数名 / 実引数
                        foreach (var args in rung.Fbs.Select(f => f.Args))
                        {
                            symbols.AddRange(args.Select(a => a.ActualArg));
                        }
                    }
                }
            }

            foreach (var fbDef in fBDefines)
            {
                foreach (var rung in fbDef.Body.Rungs)
                {
                    // LD命令で使ってる変数
                    symbols.AddRange(rung.Contacts.Select(c => c.Variable));

                    // Out命令で使ってる変数
                    symbols.AddRange(rung.Coils.Select(c => c.Variable));

                    // FB インスタンス変数
                    symbols.AddRange(rung.Fbs.Select(f => f.InstanceName));

                    // FB/FUN　引数名 / 実引数
                    foreach (var args in rung.Fbs.Select(f => f.Args))
                    {
                        symbols.AddRange(args.Select(a => a.ActualArg));
                    }
                }
            }

            var removedNull = symbols.Where(s => !string.IsNullOrEmpty(s));
            var longestLength = removedNull.Max(s => s.Length);
            return removedNull.FirstOrDefault(s => s.Length == longestLength);
        }

        private static string GetLongestFbFunNameInLadderProgram(IReadOnlyList<Program> programs)
        {
            var symbols = new List<string>();
            foreach (var program in programs)
            {
                foreach (var section in program.Sections)
                {
                    foreach (var rung in section.Rungs)
                    {
                        symbols.AddRange(rung.Fbs.Select(f => f.FbName));
                    }
                }
            }
            if (symbols.Count == 0) return String.Empty;
            var longestLength = symbols.Max(s => s.Length);
            return symbols.FirstOrDefault(s => s.Length == longestLength);
        }
    }
}
