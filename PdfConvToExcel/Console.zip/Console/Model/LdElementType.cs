﻿using Newtonsoft.Json.Linq;
using Utils;

namespace OmProjectAnalyzer.Models
{
    public enum LdElementType
    {
        LD,
        Out, // out
        FB,
        FUN,
        IST, // BOXST
        None,
    }

    public static class InstTypeExtensions
    {
        public static LdElementType GetLdElementType(this JToken token)
        {
            var ldElementTypeStr = token.GetStr("__type");
            if (ldElementTypeStr.Equals("LD"))
            {
                return LdElementType.LD;
            }
            // STはout命令のこと。
            else if (ldElementTypeStr.Equals("ST"))
            {
                return LdElementType.Out;
            }
            else if (ldElementTypeStr.Equals("FB"))
            {
                return LdElementType.FB;
            }
            else if (ldElementTypeStr.Equals("F"))
            {
                return LdElementType.FUN;
            }
            else if (ldElementTypeStr.Equals("IST")) {
                return LdElementType.IST;
            }
            return LdElementType.None;
        }
    }
}


