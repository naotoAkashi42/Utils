﻿namespace OmProjectAnalyzer.Models
{
    public enum ArgType
    {
        In,
        Out,
    }
}


