﻿using Newtonsoft.Json.Linq;
using Utils;

namespace OmProjectAnalyzer.Models
{
    public class BoxST
    {
        public string? Text { get;}
        public BoxST(JToken token)
        {
            Text = token.GetStr("TXT");
        }
    }
}
