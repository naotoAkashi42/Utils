﻿using Newtonsoft.Json.Linq;
using Utils;

namespace OmProjectAnalyzer.Models
{
    public class Coil
    {
        public LdElementType InstType { get; } = LdElementType.Out;
        public string? Variable { get; } = String.Empty;

        public int X { get; }
        public int Y { get; }

        public Coil(JToken token)
        {
            Variable = token.GetStr("Var");
            X = int.TryParse(token.GetStr("X"), out var x) ? x : 0;
            Y = int.TryParse(token.GetStr("Y"), out var y) ? y : 0;
        }
    }
}


