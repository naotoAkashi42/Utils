﻿namespace OmProjectAnalyzer.Models
{
    public class LdSection
    {
        public string? Name { get;}

        public IReadOnlyList<Rung> Rungs { get; }
        public LdSection(string name, IReadOnlyList<Rung> runs)
        {
            Name = name;
            Rungs = runs;
        }

        public IReadOnlyList<string> GetAllSymbols()
        {
            var symbols = new List<string>();
            foreach (var rung in Rungs)
            {
                symbols.AddRange(rung.GetAllSymbols());
            }
            return symbols;
        }
    }
}


