﻿
namespace OmProjectAnalyzer.Models
{
    public class Program
    {
        public string? Name { get; }
        public ProgramType ProgramType;
        public IReadOnlyList<LdSection> Sections { get; }

        public Program(string name, IReadOnlyList<LdSection> sections)
        {
            Name = name;
            Sections = sections;
        }

        public IReadOnlyList<string> GetAllSymbols()
        {
            var symbols = new List<string>();
            foreach (var section in Sections)
            {
                symbols.AddRange(section.GetAllSymbols());
            }
            return symbols;
        }
    }
}


