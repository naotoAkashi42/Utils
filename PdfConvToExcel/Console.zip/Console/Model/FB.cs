﻿
using Utils;
using Newtonsoft.Json.Linq;

namespace OmProjectAnalyzer.Models
{
    public partial class FB
    {
        public LdElementType LdElementType { get; }

        public string? FbName { get; }
        public string? InstanceName { get;}

        public int X { get; }
        public int Y { get; }

        public IReadOnlyList<FbArg> Args { get; }

        public FB(JToken token, LdElementType ldEle)
        {
            if(!(ldEle == LdElementType.FUN || ldEle == LdElementType.FB))
            {
                throw new ArgumentException();
            }
            LdElementType = ldEle;
            FbName = token.GetStr("Name");
            InstanceName = token.GetStr("Var");
            X = int.TryParse(token.GetStr("X"), out var x) ? x : 0;
            Y = int.TryParse(token.GetStr("Y"), out var y) ? y : 0;

            var argList = new List<FbArg>();
            foreach (var inArgToken in token["In"].Children())
            {
                var inArg = new FbArg();
                inArg.ArgType = ArgType.In;
                inArg.Name = inArgToken.GetStr("Arg");

                if (inArgToken.GetStr("__type").Equals("PRM"))
                {
                    if (int.TryParse(inArgToken.GetStr("Ix"), out var idx))
                    {
                        inArg.Idx = idx;
                    }
                    inArg.DataType = inArgToken.GetStr("Type");
                    inArg.ActualArg = inArgToken.GetStr("Var");
                }
                argList.Add(inArg);
            }
            foreach (var outArgToken in token["Out"].Children())
            {
                var outArg = new FbArg();
                outArg.ArgType = ArgType.Out;
                outArg.Name = outArgToken["Arg"].ToString();

                if (outArgToken.GetStr("__type").Equals("PRM"))
                {
                    outArg.Idx = int.Parse(outArgToken.GetStr("Ix"));
                    outArg.DataType = outArgToken.GetStr("Type");
                    outArg.ActualArg = outArgToken.GetStr("Var");
                }
                argList.Add(outArg);
            }
            Args = argList;
        }

        public class FbArg
        {
            public ArgType ArgType { get; set; }
            public int Idx { get; set; }
            public string? Name { get; set; }
            public string? DataType { get; set; }

            public string? ActualArg { get; set; }
        }
    }
}


