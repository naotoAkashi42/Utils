﻿using Newtonsoft.Json.Linq;
using Utils;

namespace OmProjectAnalyzer.Models
{
    public class Contact
    {
        public LdElementType InstType { get; } = LdElementType.LD;
        public string? Variable { get;}

        public int X { get; }
        public int Y { get; }

        public Contact(JToken token)
        {
            Variable = token.GetStr("Var");
            X = int.TryParse(token.GetStr("X"), out var x) ? x : 0;
            Y = int.TryParse(token.GetStr("Y"), out var y) ? y : 0;
        }
    }
}


