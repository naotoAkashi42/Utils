﻿
namespace OmProjectAnalyzer.Models
{
    public class FBDefine
    {
        // TODO : STの対応
        public ProgramType ProgramType { get; set; }
        public string Name { get; set; }
        public LdSection Body { get; set; }

        public FBDefine(string name, LdSection body)
        {
            Name = name;
            Body = body;
        }
    }
}
