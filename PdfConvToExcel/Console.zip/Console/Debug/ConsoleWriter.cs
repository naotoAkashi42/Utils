﻿using Newtonsoft.Json.Linq;
using OmProjectAnalyzer.Models;
using OmProjectAnalyzer.Parser;

namespace OmProjectAnalyzer
{
    internal class ConsoleWriter
    {
        public static void OutputProgramInfo(IReadOnlyList<Program> programs)
        {
            var instructionList = new List<string>();
            foreach (var program in programs)
            {
                Console.WriteLine($"ProgramName: {program.Name}");
                var variableList = new List<string>();

                foreach (var section in program.Sections)
                {
                    Console.WriteLine($"SectionName: {section.Name}");
                    foreach (var rung in section.Rungs)
                    {
                        var contacts = rung.Contacts;
                        var coils = rung.Coils;
                        var fbs = rung.Fbs;

                        variableList.AddRange(contacts.Select(c => c.Variable));
                        variableList.AddRange(coils.Select(c => c.Variable));
                        variableList.AddRange(fbs.Select(f => f.InstanceName));
                        foreach (var args in fbs.Select(f => f.Args))
                        {
                            variableList.AddRange(args.Select(a => a.ActualArg));
                        }
                    }
                    // 使用してる変数のリスト
                    Console.WriteLine("--- Variables ---");
                    variableList.Where(v => !string.IsNullOrEmpty(v)).ToList().ForEach(v => Console.WriteLine(v));
                    Console.WriteLine("-----");
                    Console.WriteLine();
                }
                Console.WriteLine("------------------");
            }
        }
    }
}
