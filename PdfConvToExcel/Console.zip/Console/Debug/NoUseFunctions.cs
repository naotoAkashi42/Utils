﻿using OmProjectAnalyzer.Models;
using System.Text;
using Utils;

namespace OmProjectAnalyzer.Debug
{
    internal class NoUseFunctions
    {
        public static void OutputLDProgramReqCellNumInfo(IReadOnlyList<Program> programs, IReadOnlyList<FBDefine> fBDefines, FileInfo target)
        {
            var projectName = Path.GetFileNameWithoutExtension(target.FullName);
            using (var sr = new StreamWriter(Path.Combine(FileIo.DesktopFullPath, $"result_reqCellNum.csv"), true, Encoding.UTF8))
            {
                foreach (var program in programs)
                {
                    foreach (var section in program.Sections)
                    {
                        foreach (var rung in section.Rungs)
                        {
                            var rowCnt = 0;
                            foreach (var mn in rung.GetRowMnemonics())
                            {
                                sr.WriteLine($"{program.Name}-{section.Name}-RungNo.{rung.Idx}-Row.{rowCnt},{mn}");
                                rowCnt++;
                            }
                        }
                    }
                }

                foreach (var fbDef in fBDefines)
                {
                    foreach (var rung in fbDef.Body.Rungs)
                    {
                        var rowCnt =0;
                        foreach (var mn in rung.GetRowMnemonics())
                        {
                            sr.WriteLine($"{fbDef.Name}-RungNo.{rung.Idx}-Row.{rowCnt},{mn}");
                            rowCnt++;
                        }
                    }
                }
            }
        }

        public static void OutputProgarmLadderInfoToConsole(IReadOnlyList<Program> programs)
        {
            foreach (var program in programs)
            {
                Console.WriteLine(program.Name);
                foreach (var section in program.Sections)
                {
                    Console.WriteLine(section.Name);
                    foreach (var rung in section.Rungs)
                    {
                        Console.Write($"No.{rung.Idx} LD:{rung.Contacts.Count} OUT:{rung.Coils.Count} FB/FUN:{rung.Fbs.Count} BOXST:{rung.BoxSTs.Count}");
                        Console.WriteLine();
                    }
                    Console.WriteLine();
                }
                Console.WriteLine("------------");
            }
        }
    }
}
