﻿using Newtonsoft.Json.Linq;
using OmProjectAnalyzer.Models;
using System.Xml.Linq;
using Utils;

namespace OmProjectAnalyzer.Parser
{
    public class Factory
    {
        public static IReadOnlyList<Program> CreateProgarams(FileInfo targetSmc2Info)
        {
            var desktop = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            var tmpDir = FileIo.CreateTmpDirIfNotExists(desktop);

            // Smc2ファイルを解凍 戻り値は解凍先フォルダ
            var compressedDir = FileIo.CompressFileToTempDir(targetSmc2Info);

            // OEMファイルを探す。
            var oemFileFullPath = Directory.GetFiles(compressedDir, "*.oem", SearchOption.AllDirectories).FirstOrDefault();
            if (string.IsNullOrEmpty(oemFileFullPath))
            {
                throw new Exception("OEMファイルが存在しません。");
            }

            // ラダー情報が入っているファイルを探す
            var programInfos = GetSmc2ProgramInfos(oemFileFullPath, GetWorkDirInfo(oemFileFullPath, compressedDir));
            var programs = new List<Program>();
            foreach (var programInfo in programInfos)
            {
                var sections = new List<LdSection>();
                foreach (var secInfo in programInfo.SectionInfo)
                {
                    var rungs = new List<Rung>();
                    var rungIdx = 0;

                    foreach (var jsonText in File.ReadAllLines(secInfo.SorceFileInfo.FullName))
                    {
                        var contactList = new List<Contact>();
                        var coilList = new List<Coil>();
                        var fbList = new List<FB>();
                        var boxStList = new List<BoxST>();

                        var jObj = JObject.Parse(jsonText);
                        var elems = jObj.GetStr("CLs");
                        foreach (var elem in jObj["CLs"].Children())
                        {
                            var instType = elem.GetLdElementType();
                            switch (instType)
                            {
                                case LdElementType.LD:
                                    contactList.Add(new Contact(elem));
                                    break;
                                case LdElementType.Out:
                                    coilList.Add(new Coil(elem));
                                    break;
                                case LdElementType.FB:
                                case LdElementType.FUN:
                                    fbList.Add(new FB(elem, instType));
                                    break;
                                case LdElementType.IST:
                                    boxStList.Add(new BoxST(elem));
                                    break;
                                default:
                                    break;
                            }
                        }
                        rungs.Add(new Rung(rungIdx, contactList, coilList, fbList, boxStList));
                        rungIdx++;
                    }
                    sections.Add(new LdSection(secInfo.Name, rungs));
                }
                programs.Add(new Program(programInfo.Name, sections));
            }
            return programs;
        }
        
        public static IReadOnlyList<FBDefine> CreateFBDefines(FileInfo targetSmc2Info)
        {
            var desktop = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            var tmpDir = FileIo.CreateTmpDirIfNotExists(desktop);

            // Smc2ファイルを解凍 戻り値は解凍先フォルダ
            var compressedDir = FileIo.CompressFileToTempDir(targetSmc2Info);

            // OEMファイルを探す。
            var oemFileFullPath = Directory.GetFiles(compressedDir, "*.oem", SearchOption.AllDirectories).FirstOrDefault();
            if (string.IsNullOrEmpty(oemFileFullPath))
            {
                throw new Exception("OEMファイルが存在しません。");
            }
            var fbDefineInfos = GetSmc2FbDefineInfos(oemFileFullPath, GetWorkDirInfo(oemFileFullPath, compressedDir));

            var fbDefineList = new List<FBDefine>();
            foreach (var fbDef in fbDefineInfos)
            {
                var rungIdx = 0;
                var rungs = new List<Rung>();
                foreach (var jsonText in File.ReadAllLines(fbDef.SourceFileInfo.FullName))
                {
                    var contactList = new List<Contact>();
                    var fbList = new List<FB>();
                    var coilList = new List<Coil>();
                    var boxStList = new List<BoxST>();

                    JObject jObj;
                    try
                    {
                        jObj = JObject.Parse(jsonText);
                    }
                    catch (Exception ex)
                    {
                        continue;
                    }
                    var elems = jObj.GetStr("CLs");
                    foreach (var elem in jObj["CLs"].Children())
                    {
                        var instType = elem.GetLdElementType();
                        switch (instType)
                        {
                            case LdElementType.LD:
                                contactList.Add(new Contact(elem));
                                break;
                            case LdElementType.Out:
                                coilList.Add(new Coil(elem));
                                break;
                            case LdElementType.FB:
                            case LdElementType.FUN:
                                fbList.Add(new FB(elem, instType));
                                break;
                            case LdElementType.IST:
                                boxStList.Add(new BoxST(elem));
                                break;
                            default:
                                break;
                        }
                    }
                    rungs.Add(new Rung(rungIdx, contactList, coilList, fbList, boxStList));
                    rungIdx++;
                }
                fbDefineList.Add(new FBDefine(fbDef.DefineName, new LdSection(fbDef.DefineName, rungs)));
            }
            return fbDefineList;
        }

        private static IReadOnlyList<Smc2ProgramInfo> GetSmc2ProgramInfos(string oemFileFullPath, DirectoryInfo workDirInfo)
        {
            var xml = XElement.Load(oemFileFullPath);
            var programElements = new List<XElement>();
            if (Xml.TryGetTargetElemnts(xml, "Entity", out var elements))
            {
                programElements = elements.Where(e => e.FirstAttribute.Value == "Program").ToList();

                // TODO : STの対応
                programElements = programElements.Where(e => e.Attribute("subtype").Value == "MultipartLadder").ToList();
            }
            if (programElements == null) return null;

            var targetFiles = new List<string>();
            var programInfoList = new List<Smc2ProgramInfo>();
            foreach (var element in programElements)
            {
                Xml.TryGetTargetElemnts(element, "Entity", out var sections);
                var pouBodys = sections.Where(e => e.FirstAttribute.Value == "PouBody");

                var sectionInfoList = new List<Smc2SectionInfo>();
                foreach (var pouBody in pouBodys)
                {
                    var sectionInfo = new Smc2SectionInfo();
                    sectionInfo.Name = pouBody.Attribute("name").Value;
                    sectionInfo.SorceFileInfo = new FileInfo(Path.Combine(workDirInfo.FullName, string.Concat(pouBody.Attribute("id").Value, ".xml")));
                    sectionInfoList.Add(sectionInfo);
                }
                var programInfo = new Smc2ProgramInfo();
                programInfo.Name = element.Attribute("name").Value;
                programInfo.SectionInfo = sectionInfoList;
                programInfoList.Add(programInfo);
            }
            return programInfoList;
        }

        private static IReadOnlyList<Smc2FbDefineInfo> GetSmc2FbDefineInfos(string oemFileFullPath, DirectoryInfo workDirInfo)
        {
            var xml = XElement.Load(oemFileFullPath);
            var fbDefineElements = new List<XElement>();
            if (Xml.TryGetTargetElemnts(xml, "Entity", out var elements))
            {
                fbDefineElements = elements.Where(e => e.FirstAttribute.Value == "FunctionBlock").ToList();

                // TODO : STの対応
                fbDefineElements = fbDefineElements.Where(e => e.Attribute("subtype").Value == "Ladder").ToList();
            }
            if (fbDefineElements == null) return null;

            var targetFiles = new List<string>();
            var fbDefineInfoList = new List<Smc2FbDefineInfo>();
            foreach (var element in fbDefineElements)
            {
                Xml.TryGetTargetElemnts(element, "Entity", out var fbEntity);
                var fbBody = fbEntity.Where(e => e.FirstAttribute.Value == "PouBody").First();

                var fbDefineInfo = new Smc2FbDefineInfo();
                fbDefineInfo.DefineName = element.Attribute("name").Value;
                fbDefineInfo.SourceFileInfo = new FileInfo(Path.Combine(workDirInfo.FullName, string.Concat(fbBody.Attribute("id").Value, ".xml")));

                fbDefineInfoList.Add(fbDefineInfo);
            }
            return fbDefineInfoList;
        }

        //TODO: Util的なところに移動。
        private static DirectoryInfo GetWorkDirInfo(string oemFileFullPath, string compressedDir)
        {
            var xml = XElement.Load(oemFileFullPath);
            var solutionId = string.Empty;
            if (Xml.TryGetTargetElemnts(xml, "Entity", out var elements))
            {
                solutionId = elements.Where(e => e.FirstAttribute.Value == "Solution").First().Attribute("id").Value;
            }
            return new DirectoryInfo(Path.Combine(compressedDir, solutionId));
        }
    }
}
