﻿using System.IO.Compression;

namespace Utils
{
    public class FileIo
    {
        public static string DesktopFullPath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop));
        public static string CompressFileToTempDir(FileInfo targetFile)
        {
            var desktopFullPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            var extractTargetFullPath = Path.Combine(desktopFullPath, @"temp", Path.GetFileNameWithoutExtension(targetFile.Name));
            if (Directory.Exists(extractTargetFullPath))
            {
                Directory.Delete(extractTargetFullPath, true);
            }
            ZipFile.ExtractToDirectory(targetFile.FullName, extractTargetFullPath);
            return extractTargetFullPath; 
        }

        public static IReadOnlyList<FileInfo> GetTargetFiles(string ext)
        {
            using (var form = new OpenFileDialog())
            {
                form.Filter = ext;
                form.Multiselect = true;
                var result = form.ShowDialog();

                if (result == DialogResult.Cancel) return null;
                var targetList = new List<FileInfo>();

                form.FileNames.ForEach(fileName => targetList.Add(new FileInfo(fileName)));

                return targetList;
            }
        }

        public static string CreateTmpDirIfNotExists(string parentDir)
        {
            //temp フォルダを作る。
            var tempDirFullPath = Path.Combine(parentDir, "temp");
            if (!Directory.Exists(tempDirFullPath))
            {
                Directory.CreateDirectory(tempDirFullPath);
            }
            return tempDirFullPath;
        }
    }
}