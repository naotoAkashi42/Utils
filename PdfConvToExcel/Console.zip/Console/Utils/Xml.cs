﻿using System.Xml.Linq;

namespace Utils
{
    public class Xml
    {
        public static bool TryGetTargetElemnts(XElement xml, string targetName, out IReadOnlyList<XElement> xElements)
        {
            xElements = null;
            if (xml == null) return false;

            try
            {
                xElements = xml.Descendants(targetName).ToList();
            }
            catch
            {
                return false;
            }
            return true;
        }
    }
}
