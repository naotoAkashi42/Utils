﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utils
{
    public static class Extentions
    {
        public static void ForEach<T>(this IEnumerable<T> source, Action<T> action)
        {
            foreach (var item in source)
            {
                action(item);
            }
        }

        public static string GetStr(this JToken token, string key)
        {
            try
            {
                return token[key].ToString();
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }


    }
}
