﻿namespace OmProjectAnalyzer.Models
{
    public class LdSection
    {
        public string? Name { get;}

        public IReadOnlyList<Rung> Rungs { get; }
        public LdSection(string name, IReadOnlyList<Rung> runs)
        {
            Name = name;
            Rungs = runs;
        }
    }
}


