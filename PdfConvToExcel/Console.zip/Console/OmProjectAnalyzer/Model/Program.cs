﻿
namespace OmProjectAnalyzer.Models
{
    public class Program
    {
        public string? Name { get; }
        public ProgramType ProgramType;
        public IReadOnlyList<LdSection> Sections { get; }

        public Program(string name, IReadOnlyList<LdSection> sections)
        {
            Name = name;
            Sections = sections;
        }
    }
}


