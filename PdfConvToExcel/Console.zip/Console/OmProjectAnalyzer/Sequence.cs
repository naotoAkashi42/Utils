﻿using System.Xml.Linq;
using Utils;
using OmProjectAnalyzer.Parser;
using OmProjectAnalyzer.Analyzer;

namespace OmProjectAnalyzer
{
    public class Sequence
    {
        [STAThread]
        static void Main(string[] args)
        {
            var targets = FileIo.GetTargetFiles("siemens project file |*.smc2");
            if (targets == null) return;

            //temp フォルダを作る。
            var desktopFullPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            var tempDirFullPath = Path.Combine(desktopFullPath, "temp");

            foreach(var target in targets)
            {
                var programs = Factory.CreateProgarams(target);
                var fbDefs = Factory.CreateFBDefines(target);
                ProgramAnalyzer.OutputVariableAndParams(programs, fbDefs, target);
                ProgramAnalyzer.OutputProgarmLadderInfoToCsv(programs, fbDefs, target);
                //ProgramAnalyzer.OutputLDProgramReqCellNumInfo(programs, fbDefs, target);
            }


            //var fbDefines = Factory.CreateFBDefine(targets.First());
            //var longestSymbol = Analyzer.ProgramAnalyzer.GetLongestSymbolNameInLadderProgram(programs);
            //Console.WriteLine($"Ladderプログラム内で使用されている最も長いシンボル = {longestSymbol} \n Len = {longestSymbol.Length}");

            // tempフォルダ削除する。
            Directory.Delete(tempDirFullPath, true);
        }
    }
}

