﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OmProjectAnalyzer.Parser
{
    internal class Smc2FbDefineInfo
    {
        public string DefineName { get; set; }

        public FileInfo SourceFileInfo { get; set; }
    }
}
