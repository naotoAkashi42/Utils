﻿using Newtonsoft.Json.Linq;

namespace OmProjectAnalyzer.Parser
{
    public class Smc2ProgramInfo
    {
        public string Name { get; set; }

        public IReadOnlyList<Smc2SectionInfo> SectionInfo { get; set; }




        // private Mesthod for Debug
        private void Output()
        {
            Console.WriteLine($"ProgramName: {Name}");
            Console.WriteLine();

            foreach (var secInfo in SectionInfo)
            {
                Console.WriteLine($"SectionName:{secInfo.Name}");
                foreach (var line in File.ReadLines(secInfo.SorceFileInfo.FullName))
                {
                    var jObj = JObject.Parse(line);
                    var rungs = jObj["CLs"].Children();
                    foreach (var ldElement in rungs)
                    {
                        Console.WriteLine($"Instruction: {ldElement["__type"]} variable: {ldElement["Var"]}");
                        if (IsFB(ldElement))
                        {
                            OutputFBInfo(ldElement);
                        }
                        Console.WriteLine();
                    }
                }
                Console.WriteLine("-----");
            }
        }
        private static void OutputFBInfo(JToken token)
        {
            if (!IsFB(token)) return;
            Console.Write($"FBName: {token["Name"].ToString()} ");

            var inArgs = token["In"].Children();
            Console.WriteLine("--In Arg Info--");
            foreach(var e in inArgs)
            {
                Console.Write($"In Arg Type: {e["Type"]} ");
                Console.Write($"In Arg Name: {e["Arg"]} ");
            }
            Console.WriteLine();
            Console.WriteLine("---------");

            Console.WriteLine("--Out Arg Info--");
            var outArgs = token["In"].Children();
            foreach (var e in outArgs)
            {
                Console.Write($"Out Arg Type: {e["Type"]} ");
                Console.Write($"Out Arg Name: {e["Arg"]} ");
            }
            Console.WriteLine();
            Console.WriteLine("---------");
        }
        private static bool IsFB(JToken ldElment)
        {
            return ldElment["__type"].ToString().Equals("FB");
        }
    }
}

