﻿namespace OmProjectAnalyzer
{
    public class Smc2SectionInfo
    {
        public string Name { get; set; }
        public FileInfo SorceFileInfo { get; set; }
    }
}

