﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using Utilities;

namespace SiProjectAnalyzer.Service
{
    public class LDProgramInfo
    {
        public static void Output(IReadOnlyList<FileInfo> xmlInfos)
        {
            using (var sr = new StreamWriter(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), $"result.csv")))
            {
                foreach (var xmlInfo in xmlInfos)
                {
                    var projectDir = FileIo.FixPath(new DirectoryInfo(xmlInfo.DirectoryName), ".ap17");
                    var projectName = Path.GetFileNameWithoutExtension(projectDir.Name);

                    var xml = XElement.Load(xmlInfo.FullName);

                    if (!xml.TryGetTargetElements("Name", out var progaramName)) continue;
                    if (!xml.TryGetTargetElements("ProgrammingLanguage", out var lang)) continue;
                    if (!lang.First().Value.Equals("LAD")) continue;

                    sr.WriteLine($"Project Name,{projectName}");
                    sr.WriteLine($"Program Name,{progaramName.FirstOrDefault().Value}");
                    sr.WriteLine($"Programming Language,{lang.FirstOrDefault().Value}");

                    var inputPrms = new List<string>();
                    var outputPrms = new List<string>();
                    var staticPrms = new List<string>();
                    var inOutPrms = new List<string>();
                    var tempPrms = new List<string>();
                    var constPrms = new List<string>();
                    if (xml.TryGetTargetElements("Section", out var sections))
                    {
                        foreach (var s in sections)
                        {
                            if (!s.TryGetAttributeValue("Name", out var prmTypeName)) continue;

                            if (s.TryGetTargetElements("Member", out var members))
                            {
                                foreach (var m in members)
                                {
                                    if (!m.TryGetAttributeValue("Name", out var memberName)) continue;
                                    if (prmTypeName.Equals("Input")) inputPrms.Add(memberName);
                                    if (prmTypeName.Equals("Output")) outputPrms.Add(memberName);
                                    if (prmTypeName.Equals("InOut")) inOutPrms.Add(memberName);
                                    if (prmTypeName.Equals("Static")) staticPrms.Add(memberName);
                                    if (prmTypeName.Equals("Temp")) tempPrms.Add(memberName);
                                    if (prmTypeName.Equals("Constant")) constPrms.Add(memberName);
                                }
                            }
                        }
                    }

                    sr.WriteLine("Parameters");
                    sr.WriteLine($",Input,{ string.Join(",", inputPrms)}");
                    sr.WriteLine($",Output,{ string.Join(",", outputPrms)}");
                    sr.WriteLine($",InOut,{ string.Join(",", inOutPrms)}");
                    sr.WriteLine($",Static,{ string.Join(",", staticPrms)}");
                    sr.WriteLine($",Temp,{ string.Join(",", tempPrms)}");
                    sr.WriteLine($",Constant,{ string.Join(",", constPrms)}");

                    if (!xml.TryGetTargetElements("NetworkSource", out var netWorks)) continue;

                    sr.WriteLine($"In Ladder Info");
                    var rungNumber = 0;
                    var programVariables = new List<string>();
                    foreach (var nt in netWorks)
                    {
                        sr.WriteLine($"Rung No.{rungNumber}");
                        var variables = new List<string>();
                        var prms = new List<string>();
                        var userFb = new List<string>();
                        var builtinFb = new List<string>();
                        // variables
                        if (nt.TryGetTargetElements("Component", out var components))
                        {
                            foreach (var c in components)
                            {
                                if (!c.TryGetAttributeValue("Name", out var value)) continue;
                                variables.Add(value);
                                programVariables.AddRange(variables);
                            }
                        }

                        // user FB/FUN
                        if (nt.TryGetTargetElements("CallInfo", out var callInfos))
                        {
                            userFb.AddRange(callInfos.Select(c => c.GetAttributeValue("Name")));

                            foreach (var c in callInfos)
                            {
                                if (!c.TryGetTargetElements("Parameter", out var parameters)) continue;
                                foreach (var p in parameters)
                                {
                                    if (!p.TryGetAttributeValue("Name", out var value)) continue;
                                    prms.Add(value);
                                }
                            }
                        }

                        // built in FB/FUN
                        if (nt.TryGetTargetElements("Part", out var parts))
                        {
                            foreach (var p in parts)
                            {
                                if (!p.TryGetAttributeValue("Name", out var value)) continue;
                                builtinFb.Add(value);
                            }
                        }
                        sr.WriteLine($",Variables,{ string.Join(",", variables)}");
                        sr.WriteLine($",Called UserFBFUN,{ string.Join(",", userFb)}");
                        sr.WriteLine($",Called Inst/BuiltinFBFUN,{ string.Join(",", builtinFb)}");
                        sr.WriteLine($"Element Count in rung,{userFb.Count + builtinFb.Count}");
                        rungNumber++;
                    }
                    if (programVariables.Count != 0) sr.WriteLine($"average variable length in this Program,{programVariables.Average(v => v.Length)}");
                    sr.WriteLine();
                }
            }
        }
    }
}
