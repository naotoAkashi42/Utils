﻿using SiProjectAnalyzer.Model.ProgramBlock;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using Utilities;

namespace SiProjectAnalyzer.Parser
{
    internal class DataBlockParser
    {
        public static DataBlock Parse(FileInfo sourceXml)
        {
            var xml = XElement.Load(sourceXml.FullName);
            if (!xml.TryGetTargetElement("SW.Blocks.GlobalDB", out var dbXe) &&
                !xml.TryGetTargetElement("SW.Blocks.InstanceDB", out dbXe)) return null;
                
            var dbName = dbXe.TryGetTargetElement("Name", out var nameXe) ? nameXe.Value : string.Empty;

            string dbComment = string.Empty;
            if(dbXe.TryGetTargetElement("MultilingualText", out var dbCommentXe))
            {
                dbComment = dbCommentXe.TryGetTargetElement("Text", out var textXe) ? textXe.Value : string.Empty;
            }

            if (!dbXe.TryGetTargetElements("Section", out var sectionsXe)) return null;
            var parameters = new List<Paramter>();
            foreach (var secXe in sectionsXe)
            {
                if (!secXe.TryGetAttributeValue("Name", out var dbParamTypeStr)) continue;
                if (!secXe.TryGetTargetElements("Member", out var membersXe)) continue;

                var fbparamType = FBParamterTypeExtensions.GetFBParamterType(dbParamTypeStr);
                var memberNameStr = string.Empty;
                var memberdataTypeStr = string.Empty;
                var temp = string.Empty;

                string retain = string.Empty;
                string exAccess = string.Empty;
                string exVis = string.Empty;
                string exWrite = string.Empty;
                string userVis = string.Empty;
                string userReadOnly = string.Empty;
                string userDelete = string.Empty;
                string setPoint = string.Empty;
                string defaultValue = string.Empty;
                string comment = string.Empty;

                foreach (var memberXe in membersXe)
                {
                    memberNameStr = memberXe.TryGetAttributeValue("Name", out temp) ? temp : string.Empty;
                    memberdataTypeStr = memberXe.TryGetAttributeValue("Datatype", out temp) ? temp : string.Empty;
                    retain = memberXe.TryGetAttributeValue("Remanence", out temp) ? temp : string.Empty;

                    if (!memberXe.TryGetTargetElements("BooleanAttribute", out var bAttsXe)) continue;
                    foreach (var bAttXe in bAttsXe)
                    {
                        if (!bAttXe.TryGetAttributeValue("Name", out var bAttType)) continue;

                        if (bAttType.Equals("ExternalAccessible")) exAccess = bAttXe.Value;
                        if (bAttType.Equals("ExternalVisible")) exVis = bAttXe.Value;
                        if (bAttType.Equals("ExternalWritable")) exWrite = bAttXe.Value;
                        if (bAttType.Equals("UserVisible")) userVis = bAttXe.Value;
                        if (bAttType.Equals("UserReadOnly")) userReadOnly = bAttXe.Value;
                        if (bAttType.Equals("UserDeletable")) userDelete = bAttXe.Value;
                    }

                    defaultValue = memberXe.TryGetTargetElement("StartValue", out var defValXe) ? defValXe.Value : string.Empty;
                    comment = memberXe.TryGetTargetElement("MultiLanguageText", out var memberCommentXe) ? memberCommentXe.Value : string.Empty;

                    parameters.Add(new Paramter(fbparamType, memberNameStr, memberdataTypeStr, defaultValue, comment,
                                new PbMemberBoolenAttribute(exAccess, exVis, exWrite, retain, userVis, userReadOnly, userDelete, setPoint)));
                }
            }
            return new DataBlock(dbName, dbComment, parameters);
        }
    }
}
