﻿namespace SiProjectAnalyzer.Model.ProgramBlock
{
    public enum FBParamterType
    {
        Input,
        Output,
        InOut,
        Static,
        Temp,
    }

    public static class FBParamterTypeExtensions
    {
        private static IReadOnlyDictionary<FBParamterType, string> _dic = new Dictionary<FBParamterType, string>
        {
            { FBParamterType.Input, "Input"},
            { FBParamterType.Output, "Output"},
            { FBParamterType.InOut, "InOut"},
            { FBParamterType.Static, "Static"},
            { FBParamterType.Temp, "Temp"}
        };

        public static FBParamterType GetFBParamterType(string strKey)
        {
            var pair = _dic.FirstOrDefault(c => c.Value == strKey);
            return pair.Key;
        }

        public static string ToString(this FBParamterType type)
        {
            return _dic[type];
        }
    }
}
