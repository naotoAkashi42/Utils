﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiProjectAnalyzer.Model.ProgramBlock
{
    internal class DataBlock
    {
        public string Name { get; }

        public string Comment { get; }

        public IReadOnlyList<Paramter> Paramters { get; }
        public DataBlock(string name, string comment, IReadOnlyList<Paramter> paramters)
        {
            Name = name;
            Comment = comment;
            Paramters = paramters;
        }
    }
}
