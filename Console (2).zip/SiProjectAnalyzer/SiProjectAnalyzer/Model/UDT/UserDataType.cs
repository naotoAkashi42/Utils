﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiProjectAnalyzer.Model.UDT
{
    internal class UserDataType
    {
        public string Name { get;}
        public IReadOnlyList<UdtMember> Members { get;}

        public UserDataType(string name, IReadOnlyList<UdtMember> members)
        {
            Name = name;
            Members = members;
        }
    }

    class UdtBoolenAttribute : BoolenAttribute
    {
        public string SetPoint { get; }

        public UdtBoolenAttribute(string externAccess, string externVis, string externWrite, string setpoint)
        : base(externAccess, externVis, externWrite)
        {
            SetPoint = setpoint;
        }
    }
}
