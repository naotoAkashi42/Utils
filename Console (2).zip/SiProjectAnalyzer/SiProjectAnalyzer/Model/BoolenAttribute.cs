﻿namespace SiProjectAnalyzer.Model
{
    public class BoolenAttribute
    {
        // HMI / OPCUA / WEB APIからアクセスできるか？
        public string ExternalAccessible { get; }

        // HMI / OPCUA / WEB APIに公開するか？
        public string ExternVisible { get; }

        // HMI / OPCUA / WEB APIから書き込みできるか？
        public string ExternWritable { get; }

        public BoolenAttribute(string externAccess, string externVis, string externWrite)
        {
            ExternalAccessible = externAccess;
            ExternVisible = externVis;
            ExternWritable = externWrite;
        }
    }
}
