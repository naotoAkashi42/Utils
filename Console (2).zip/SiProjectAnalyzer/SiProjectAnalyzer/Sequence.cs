﻿using SiProjectAnalyzer.Parser;
using SiProjectAnalyzer.Service;
using System.Xml.Linq;
using Utilities;

namespace SiProjectAnalyzer
{
    public class Sequence
    {
        [STAThread]
        public static void Main(string[] args)
        {
        }
    }
}

