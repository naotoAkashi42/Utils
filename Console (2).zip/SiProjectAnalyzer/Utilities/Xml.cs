﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Utilities
{
    public static class Xml
    {
        public static string GetAttributeValue(this XElement ele, string attribute)
                            => ele == null ? string.Empty : ele.Attribute(attribute).Value;

        public static bool TryGetAttributeValue(this XElement ele, string attributeName, out string value)
        {
            value = string.Empty;
            try
            {
                value = ele.GetAttributeValue(attributeName);
            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }

        public static string GetElementValue(this XElement ele, string elementName)
        {
            if (ele == null) return string.Empty;

            try
            {
                return ele.Element(elementName).Value;
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }
        
        //public static bool TryGetNameSpace(this XElement ele, XName nameSpace)
        //{

        //}

        public static bool TryGetTargetElement(this XElement xml, string targetName, out XElement xElement)
        {
            xElement = null;
            try
            {
                xElement = xml.Descendants().Select(x => x).Where(x => x.Name.LocalName == targetName).First();
            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }

        public static bool TryGetTargetElements(this XElement xml, string targetName, out IReadOnlyList<XElement> xElements)
        {
            xElements = null;
            if (xml == null) return false;

            try
            {
                xElements = xml.Descendants().Select(x => x).Where(x => x.Name.LocalName == targetName).ToList();
            }
            catch
            {
                return false;
            }
            return (xElements.Count != 0);
        }

        //public static bool TryGetElement(this XElement xml, string targetName, out XElement xElement)
        //{
            
        //}

        public static bool TryGetChild(this XElement parent, string name, out XElement child)
        {
            child = null;
            if (parent == null) return false;

            try
            {
                child = parent.Element(name);
                if (child == null) return false;
            }
            catch
            {
                return false;
            }
            return true;
        }

        private static bool HasNamespace(XElement xElement)
        {
            return !string.IsNullOrEmpty(xElement.Name.NamespaceName);
        }
    }
}
