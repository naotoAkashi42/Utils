﻿using SiProjectAnalyzer.Parser;
using SiProjectAnalyzer.Service;
using System.Xml.Linq;
using Utilities;

namespace SiProjectAnalyzer
{
    public class Sequence
    {
        [STAThread]
        public static void Main(string[] args)
        {
            var table = PlcTagParser.Parse(new FileInfo(@"C:\Users\aksh0\OneDrive\デスクトップ\temp\Project2.ap17\PLC_2\PLC tags\Tag table_1.xml"));
            var function = FunctionParser.Parse(new FileInfo(@"C:\Users\aksh0\OneDrive\デスクトップ\temp\Project2.ap17\Block_2.xml"));
        }
    }
}

