﻿using SiProjectAnalyzer.Model;
using SiProjectAnalyzer.Model.ProgramBlock;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using Utilities;

namespace SiProjectAnalyzer.Parser
{
    internal class FunctionParser
    {
        public static Function Parse(FileInfo sourceXml)
        {
            var xml = XElement.Load(sourceXml.FullName);
            if (!xml.TryGetTargetElement("SW.Blocks.FC", out var fbXe)) return null;

            var fbName = fbXe.TryGetTargetElement("Name", out var nameXe) ? nameXe.Value : string.Empty;
            var language = fbXe.TryGetTargetElement("ProgrammingLanguage", out var languageXe) ? languageXe.Value : string.Empty;

            if (!fbXe.TryGetTargetElements("Section", out var sectionsXe)) return null;

            var parameters = new List<Paramter>();
            foreach (var secXe in sectionsXe)
            {
                if (!secXe.TryGetAttributeValue("Name", out var fbParamTypeStr)) continue;
                if (!secXe.TryGetTargetElements("Member", out var membersXe)) continue;

                var fbparamType = FBParamterTypeExtensions.GetFBParamterType(fbParamTypeStr);
                var memberNameStr = string.Empty;
                var memberdataTypeStr = string.Empty;
                var temp = string.Empty;

                string defaultValue = string.Empty;
                string comment = string.Empty;

                foreach (var memberXe in membersXe)
                {
                    memberNameStr = memberXe.TryGetAttributeValue("Name", out temp) ? temp : string.Empty;
                    memberdataTypeStr = memberXe.TryGetAttributeValue("Datatype", out temp) ? temp : string.Empty;

                    defaultValue = memberXe.TryGetTargetElement("StartValue", out var defValXe) ? defValXe.Value : string.Empty;
                    comment = memberXe.TryGetTargetElement("MultiLanguageText", out var commentXe) ? commentXe.Value : string.Empty;

                    parameters.Add(new Paramter(fbparamType, memberNameStr, memberdataTypeStr, defaultValue, comment, new PbMemberBoolenAttribute()));
                }
            }
            return new Function(fbName, ProgramLanguagesExtensions.GetProgramLanguage(language), parameters);
        }
    }
}
