﻿using SiProjectAnalyzer.Model;
using SiProjectAnalyzer.Model.UDT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using Utilities;

namespace SiProjectAnalyzer.Parser
{
    internal class UdtParser
    {
        public static UserDataType Parse(FileInfo source)
        {
            var xml = XElement.Load(source.FullName);

            if (!xml.TryGetTargetElement("SW.Types.PlcStruct", out var plcStructXe)) return null;
            if(!plcStructXe.TryGetTargetElement("Name", out var udtNameXe)) return null;

            var udtName = udtNameXe.Value; 

            if (!plcStructXe.TryGetTargetElements("Member", out var membersXe)) return null;

            var members = new List<UdtMember>();
            foreach (var memberXe in membersXe)
            {
                var name = memberXe.TryGetAttributeValue("Name", out var temp) ? temp : String.Empty;
                var dataType = memberXe.TryGetAttributeValue("Datatype", out temp) ? temp : String.Empty;

                if (!memberXe.TryGetTargetElements("BooleanAttribute", out var boolenAttsXe)) continue;

                string exAccess = string.Empty;
                string exVis = string.Empty;
                string exWrite = string.Empty;
                string setPoint = string.Empty;
                foreach (var bAttXe in boolenAttsXe)
                {
                    if (!bAttXe.TryGetAttributeValue("Name", out var attName)) continue;
                    if (attName.Equals("ExternalAccessible")) exAccess = bAttXe.Value;
                    if (attName.Equals("ExternalVisible")) exVis = bAttXe.Value;
                    if (attName.Equals("ExternalWritable")) exWrite = bAttXe.Value;
                    if (attName.Equals("SetPoint")) setPoint = bAttXe.Value;
                }

                var comment = memberXe.TryGetTargetElement("MultiLanguageText", out var commentStr) ? commentStr.Value : String.Empty;
                var defaultVal = memberXe.TryGetTargetElement("StartValue", out var defValStr) ? defValStr.Value : String.Empty;

                members.Add(new UdtMember(name, dataType, defaultVal, comment, new UdtBoolenAttribute(exAccess, exVis, exWrite, setPoint)));
            }
            return new UserDataType(udtName, members);
        }
    }
}
