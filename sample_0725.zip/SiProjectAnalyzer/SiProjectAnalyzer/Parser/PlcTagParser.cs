﻿using Utilities;
using SiProjectAnalyzer.Model.PlcTag;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace SiProjectAnalyzer.Parser
{
    internal class PlcTagParser
    {
        public static PlcTagTable Parse(FileInfo sourceXml)
        {
            var xml = XElement.Load(sourceXml.FullName);
            if (!xml.TryGetTargetElement("SW.Tags.PlcTagTable", out var plcTableXe)) return null;
            var tableName = plcTableXe.TryGetTargetElement("Name", out var tableNameXe) ? tableNameXe.Value : String.Empty;

            if (!plcTableXe.TryGetTargetElements("SW.Tags.PlcTag", out var plcTagsXe)) return null;

            var plcTags = new List<PlcTag>();
            foreach (var pTagXe in plcTagsXe)
            {
                var tagName = pTagXe.TryGetTargetElement("Name", out var tagNameXe) ? tagNameXe.Value : String.Empty;
                var datatype = pTagXe.TryGetTargetElement("DataTypeName", out var datatypeXe) ? datatypeXe.Value : String.Empty;
                var exAccses = pTagXe.TryGetTargetElement("ExternalAccessible", out var exAccXe) ? exAccXe.Value : String.Empty;
                var exVisible = pTagXe.TryGetTargetElement("ExternalAccessible", out var exVisXe) ? exVisXe.Value : String.Empty;
                var exWrite = pTagXe.TryGetTargetElement("ExternalAccessible", out var exWriteXe) ? exWriteXe.Value : String.Empty;

                var tagComment = string.Empty;
                if (pTagXe.TryGetTargetElement("MultilingualTextItem", out var tagCommentXe))
                {
                    tagComment = tagCommentXe.TryGetTargetElement("Text", out var textXe) ? textXe.Value : String.Empty;
                }

                plcTags.Add(new PlcTag(tagName, datatype, tagComment, new Model.BoolenAttribute(exAccses, exVisible, exWrite)));
            }
            return new PlcTagTable(tableName, plcTags);
        }
    }
}
