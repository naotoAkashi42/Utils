﻿namespace SiProjectAnalyzer.Model
{
    public class BoolenAttribute
    {
        // HMI / OPCUA / WEB APIからアクセスできるか？
        public string ExternalAccessible { get; } = String.Empty;

        // HMI / OPCUA / WEB APIに公開するか？
        public string ExternVisible { get; } = String.Empty;

        // HMI / OPCUA / WEB APIから書き込みできるか？
        public string ExternWritable { get; } = String.Empty;

        public BoolenAttribute(string externAccess, string externVis, string externWrite)
        {
            ExternalAccessible = externAccess;
            ExternVisible = externVis;
            ExternWritable = externWrite;
        }
        public BoolenAttribute()
        {

        }
    }
}
