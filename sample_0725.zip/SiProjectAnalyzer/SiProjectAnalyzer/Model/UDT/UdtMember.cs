﻿namespace SiProjectAnalyzer.Model.UDT
{
    public class UdtMember
    {
        public string Name { get;}
        public string DataType { get; }
        public string DefaultValue { get; }
        public string Comment { get; }

        public BoolenAttribute BoolenAttribute { get; }

        public UdtMember(string name, string dataType, string defaultVal, string comment, BoolenAttribute boolenAtt)
        {
            Name = name;
            DataType = dataType;
            DefaultValue = defaultVal;
            Comment = comment;
            BoolenAttribute = boolenAtt;
        }
    }
}
