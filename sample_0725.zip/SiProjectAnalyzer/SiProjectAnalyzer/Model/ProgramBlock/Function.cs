﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiProjectAnalyzer.Model.ProgramBlock
{
    internal class Function
    {
        public ProgramLanguage ProgramLanguage { get; }

        public string Name { get; }

        public IReadOnlyList<Paramter> Paramters { get; }

        public Function(string name, ProgramLanguage language, IReadOnlyList<Paramter> paramters)
        {
            Name = name;
            ProgramLanguage = language;
            Paramters = paramters;
        }
    }
}
