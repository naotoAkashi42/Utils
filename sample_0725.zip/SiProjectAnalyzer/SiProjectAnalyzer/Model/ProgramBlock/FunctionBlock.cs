﻿using SiProjectAnalyzer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiProjectAnalyzer.Model.ProgramBlock
{
    internal class FunctionBlock
    {
        public ProgramLanguage ProgramLanguage { get; }

        public string Name { get; }

        public IReadOnlyList<Paramter> Paramters { get; }

        public FunctionBlock(string name, ProgramLanguage language, IReadOnlyList<Paramter> paramters)
        {
            Name = name;
            ProgramLanguage = language;
            Paramters = paramters;
        }
    }

    class PbMemberBoolenAttribute : BoolenAttribute
    {
        public string Retain { get; } = String.Empty;
        public string UserVisible { get; } = String.Empty;
        public string UserReadOnly { get; } = String.Empty;
        public string UserDeletable { get; } = String.Empty;
        public string SetPoint { get; } = String.Empty;

        public PbMemberBoolenAttribute(string externAccess, string externVis, string externWrite, string retain,
                                 string userVis, string userReadOnly, string userDeletable, string setPoint)
        : base(externAccess, externVis, externWrite)
        {
            Retain = retain;
            UserVisible = userVis;
            UserReadOnly = userReadOnly;
            UserDeletable = userDeletable;
            SetPoint = setPoint;
        }

        public PbMemberBoolenAttribute() { }
    }
}
