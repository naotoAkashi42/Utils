﻿namespace SiProjectAnalyzer.Model.ProgramBlock
{
    class Paramter
    {
        public FBParamterType FBParamterType { get; }
        public string Name { get; }
        public string Datatype { get; }
        public string DefaultValue { get; }
        public string Comment { get; }

        public PbMemberBoolenAttribute BoolenAttribute { get; }

        public Paramter(FBParamterType type, string name, string datatype, string defVal, string cmt, PbMemberBoolenAttribute fbBoolenAttribute)
        {
            FBParamterType = type;
            Name = name;
            Datatype = datatype;
            DefaultValue = defVal;
            Comment = cmt;
            BoolenAttribute = fbBoolenAttribute;
        }
    }
}
