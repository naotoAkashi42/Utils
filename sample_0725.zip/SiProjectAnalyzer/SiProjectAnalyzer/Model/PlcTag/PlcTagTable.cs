﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiProjectAnalyzer.Model.PlcTag
{
    internal class PlcTagTable
    {
        public string Name { get; }

        public IReadOnlyList<PlcTag> PlcTags { get; }

        public PlcTagTable(string name, IReadOnlyList<PlcTag> plcTags)
        {
            Name = name;
            PlcTags = plcTags;
        }
    }
}
