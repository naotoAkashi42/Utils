﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiProjectAnalyzer.Model.PlcTag
{
    internal class PlcTag
    {
        public string Name { get;}

        public string Datatype { get;}

        public  string Comment { get; }

        public BoolenAttribute BoolenAttribute { get;}

        public PlcTag(string name, string datatype, string comment, BoolenAttribute boolenAttribute)
        {
            Name = name;
            Datatype = datatype;
            Comment = comment;
            BoolenAttribute = boolenAttribute;
        }
    }
}
