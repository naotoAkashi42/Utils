﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiProjectAnalyzer.Model
{
    public enum ProgramLanguage
    {
        LAD,
        ST,
        SFC,
        FBD,
    }

    public static class ProgramLanguagesExtensions
    {
        private static Dictionary<ProgramLanguage, string> _dic = new Dictionary<ProgramLanguage, string>
        {
            {ProgramLanguage.LAD, "LAD"},
            {ProgramLanguage.ST, "ST"},
        };

        public static ProgramLanguage GetProgramLanguage(string strKey)
        {
            var pair = _dic.FirstOrDefault(c => c.Value == strKey);
            return pair.Key;
        }

        public static string ToString(this ProgramLanguage language)
        {
            return _dic[language];
        }
    }
}
