﻿namespace Utilities
{
    public class FileIo
    {
        public static IReadOnlyList<FileInfo> GetTargetFileInfos(string ext)
        {
            using (var form = new OpenFileDialog())
            {
                form.Filter = ext;
                form.Multiselect = true;
                var result = form.ShowDialog();

                if (result == DialogResult.Cancel) return null;
                var targetList = new List<FileInfo>();

                form.FileNames.ForEach(fileName => targetList.Add(new FileInfo(fileName)));

                return targetList;
            }
        }

        public static IReadOnlyList<FileInfo> GetTargetXmlInDir()
        {
            using (var form = new FolderBrowserDialog())
            {
                var result = form.ShowDialog();

                if (result == DialogResult.Cancel) return null;

                var xmlFiles = Directory.GetFiles(form.SelectedPath, "*.xml", SearchOption.AllDirectories);

                return xmlFiles.Select(f => new FileInfo(f)).ToList();
            }
        }

        public static DirectoryInfo FixPath(DirectoryInfo folder, string keyword)
        {
            var parent = Directory.GetParent(Path.GetDirectoryName(folder.FullName));
            if (parent != null && parent.Name.Contains(keyword))
            {
                return parent;
            }
            else
            {
                return FixPath(parent, keyword);
            }
        }
    }
}