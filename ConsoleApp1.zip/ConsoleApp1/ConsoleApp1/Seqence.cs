﻿

using Newtonsoft.Json.Linq;

namespace ConsoleApp1
{
    public class Seqence
    {
        public static void Main()
        {
            var desktopFullPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

            var targetFullPath = Path.Combine(desktopFullPath, "6caa9f93-cb5e-4c23-a700-f959dbbc934e.xml");

            var cnt = 0;
            foreach (var jsonText in File.ReadAllLines(targetFullPath))
            {
                Console.WriteLine($"Network: {cnt}");
                var jObj = JObject.Parse(jsonText);
                var elems = jObj.GetStr("CLs"); 

                var constactList = new List<Contact>();
                var fbList = new List<FB>();
                var coilList = new List<Coil>();
                foreach (var elem in jObj["CLs"].Children())
                {
                    switch (elem.GetInstType())
                    {
                        case InstType.LD:
                            constactList.Add(new Contact(elem));
                            break;
                        case InstType.Out:
                            coilList.Add(new Coil(elem));
                            break;
                        case InstType.FB:
                            fbList.Add(new FB(elem));
                            break;
                        default:
                            break;
                    }
                }
                cnt++;
            }
            Console.ReadKey();
        }

    }
}


