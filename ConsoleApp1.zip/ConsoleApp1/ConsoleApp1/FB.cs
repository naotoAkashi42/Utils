﻿

using Newtonsoft.Json.Linq;

namespace ConsoleApp1
{
    public class FB
    {
        public InstType InstType { get; } = InstType.FB;

        public string? FbName { get; }
        public string? InstanceName { get;}

        public IReadOnlyList<FbArg> Args { get; }

        public FB(JToken token)
        {
            FbName = token["Name"].ToString();
            InstanceName = token["Var"].ToString();

            var argList = new List<FbArg>();
            foreach (var inArgToken in token["In"].Children())
            {
                var inArg = new FbArg();
                inArg.ArgType = ArgType.In;
                inArg.Name = inArgToken["Arg"].ToString();

                if (inArgToken["__type"].ToString().Equals("PRM"))
                {
                    inArg.Idx = int.Parse(inArgToken["Ix"].ToString());
                    inArg.DataType = inArgToken["Type"].ToString();
                    inArg.ActualArg = inArgToken["Var"].ToString();
                }
                argList.Add(inArg);
            }
            foreach (var outArgToken in token["Out"].Children())
            {
                var outArg = new FbArg();
                outArg.ArgType = ArgType.Out;
                outArg.Name = outArgToken["Arg"].ToString();

                if (outArgToken["__type"].ToString().Equals("PRM"))
                {
                    outArg.Idx = int.Parse(outArgToken["Ix"].ToString());
                    outArg.DataType = outArgToken["Type"].ToString();
                    outArg.ActualArg = outArgToken["Var"].ToString();
                }
                argList.Add(outArg);
            }
            Args = argList;
        }

        public class FbArg
        {
            public ArgType ArgType { get; set; }
            public int Idx { get; set; }
            public string? Name { get; set; }
            public string? DataType { get; set; }

            public string? ActualArg { get; set; }
        }
    }
}


