﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Analayzer
    {
        /// <summary>
        /// 変数 引数 FB/FUN名でもっとも長いものを探す。
        /// </summary>
        /// <returns></returns>
        public static string GetLongestFBName(IReadOnlyList<FB> fBs)
        {
            string longestName = string.Empty;
            longestName = fBs.Select(f => f.FbName).Max(fbName => fbName);
            return longestName;
        }
    }
}
