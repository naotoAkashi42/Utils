﻿namespace ConsoleApp1
{
    public class Program
    {
        public string? Name { get; }
        public IReadOnlyList<Section> Sections { get; }

        public Program(string name, IReadOnlyList<Section> sections)
        {
            Name = name;
            Sections = sections;
        }
    }
}


