﻿using Newtonsoft.Json.Linq;

namespace ConsoleApp1
{
    public class Contact
    {
        public InstType InstType { get; } = InstType.LD;
        public string? Variable { get;}

        public Contact(JToken token)
        {
            Variable = token.GetStr("Var");
        }
    }
}


