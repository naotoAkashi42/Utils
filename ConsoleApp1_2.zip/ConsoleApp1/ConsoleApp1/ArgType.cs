﻿namespace ConsoleApp1
{
    public enum ArgType
    {
        In,
        Out,
    }
}


