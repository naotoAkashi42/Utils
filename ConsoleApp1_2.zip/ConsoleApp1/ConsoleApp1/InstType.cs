﻿namespace ConsoleApp1
{
    public enum InstType
    {
        LD,
        Out, // out
        FB,
        FUN,
        None,
    }
}


