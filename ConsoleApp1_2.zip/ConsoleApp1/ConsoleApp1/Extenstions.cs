﻿using Newtonsoft.Json.Linq;

namespace ConsoleApp1
{
    public static class Extenstions
    {
        public static string GetStr(this JToken token, string key)
        {
            try
            {
                return token[key].ToString();
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }

        public static InstType GetInstType(this JToken token)
        {
            var instTypeStr = token["__type"].ToString();
            if (instTypeStr.Equals("LD"))
            {
                return InstType.LD;
            }
            else if (instTypeStr.Equals("ST"))
            {
                return InstType.Out;
            }
            else if (instTypeStr.Equals("FB"))
            {
                return InstType.FB;
            }
            else if (instTypeStr.Equals("FUN"))
            {
                return InstType.FUN;
            }
            return InstType.None;
        }
        public static void OutputFBInfo(JToken token)
        {
            Console.WriteLine($"FB Name: {token["Name"]}");

            Console.WriteLine("---In Args---");
            foreach (var elem in token["In"].Children())
            {
                var tmp = elem.Values();
                var hoge = elem["__type"].ToString();
                Console.Write($"ArgName: {elem["Arg"]} ");
                Console.Write($"Type: {elem["Type"]} ");
                Console.Write($"Var: {elem["Var"]} ");
                Console.WriteLine();
            }

            Console.WriteLine("---Out Args---");
            foreach (var elem in token["Out"].Children())
            {
                Console.Write($"ArgName: {elem["Arg"]} ");
                Console.Write($"Type: {elem["Type"]} ");
                Console.Write($"Var: {elem["Var"]} ");
                Console.WriteLine();
            }
        }
    }
}


