﻿using Newtonsoft.Json.Linq;

namespace ConsoleApp1
{
    public partial class Seqence
    {
        public static void Main()
        {
            var desktopFullPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

            var targetFullPathList = new List<string>();
            targetFullPathList.Add(Path.Combine(desktopFullPath, "6caa9f93-cb5e-4c23-a700-f959dbbc934e.xml"));
            targetFullPathList.Add(Path.Combine(desktopFullPath, "6d79192c-0007-4975-bd11-bcf34bbb30af.xml"));

            var programs = Factory.CreateProgram(targetFullPathList);

            Console.ReadKey();
        }
    }
}


