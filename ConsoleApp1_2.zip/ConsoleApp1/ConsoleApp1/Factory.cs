﻿using Newtonsoft.Json.Linq;

namespace ConsoleApp1
{
    public static class Factory
    {
        public static Program CreateProgram(IReadOnlyList<string> targetFullPathList)
        {
            var sections = new List<Section>();
            var constactList = new List<Contact>();
            var fbList = new List<FB>();
            var coilList = new List<Coil>();
            foreach (var item in targetFullPathList)
            {
                foreach (var jsonText in File.ReadAllLines(item))
                {
                    var jObj = JObject.Parse(jsonText);
                    var elems = jObj.GetStr("CLs");
                    foreach (var elem in jObj["CLs"].Children())
                    {
                        switch (elem.GetInstType())
                        {
                            case InstType.LD:
                                constactList.Add(new Contact(elem));
                                break;
                            case InstType.Out:
                                coilList.Add(new Coil(elem));
                                break;
                            case InstType.FB:
                                fbList.Add(new FB(elem));
                                break;
                            default:
                                break;
                        }
                    }
                }
                sections.Add(new Section("Dummy", constactList, coilList, fbList));

            }
            return new Program("Program Name", sections);
        }
    }
}


