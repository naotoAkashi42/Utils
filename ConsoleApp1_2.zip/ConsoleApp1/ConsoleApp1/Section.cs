﻿namespace ConsoleApp1
{
    public class Section
    {
        public string? Name { get;}
        public IReadOnlyList<Contact> Contacts { get; }
        public IReadOnlyList<Coil> Coils { get; }
        public IReadOnlyList<FB> Fbs { get; }

        public Section(string name, IReadOnlyList<Contact> contacts, IReadOnlyList<Coil> coils, IReadOnlyList<FB> fbs)
        {
            Name = name;
            Contacts = contacts;
            Coils = coils;
            Fbs = fbs;
        }
    }
}


