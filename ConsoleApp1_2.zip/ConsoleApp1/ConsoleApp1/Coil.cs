﻿using Newtonsoft.Json.Linq;

namespace ConsoleApp1
{
    public class Coil
    {
        public InstType InstType { get; } = InstType.Out;
        public string? Variable { get; }

        public Coil(JToken token)
        {
            Variable = token.GetStr("Var");
        }
    }
}


